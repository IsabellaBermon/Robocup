#include <stdio.h>
#include "robot_movement.h"
#include "bt_functions.h"


void getAnglesMotors(){
  tca_select_channel(0);
  angleMotor1 = angleSubtraction(getAngle(),offsetAngleMotor1);
  tca_select_channel(1);
  angleMotor2 = angleSubtraction(getAngle(),offsetAngleMotor2);
  tca_select_channel(2);
  angleMotor3 = angleSubtraction(getAngle(),offsetAngleMotor3);
  tca_select_channel(3);
  angleMotor4 = angleSubtraction(getAngle(),offsetAngleMotor4);
  tca_select_channel(4);
}




int main(){
  stdio_init_all();
  mpu_init();
  mpu6050_reset();
  initI2C();
  getOffsets();
  initBluetooth();    
  initMotor();

  calibrate();

  while (1){

    if(!banStop){
      getAnglesMotors();
      updateAngle();
    }
    // //pwm_set_chan_level(slice_num_6, PWM_CHAN_A, 780); // 780
    // // circularMovement(2,360);


    printf("ang %f\n",robotAngle);
    if(btAvailable){
      continue;
    }

    if(banAngle){
      rotation(angleBt);
    }else if(banDistance){
      moveForward(distanceBt);
    }else if(banCircularMovement){
      circularMovement(radioBt,angleTurnBt);
    }
    if(banStop){
      banAngle=false;
      banDistance=false;
      banCircularMovement=false;
      btAvailable = true;
      banStop = false;
      
    }
  }

  return 0;
}                       