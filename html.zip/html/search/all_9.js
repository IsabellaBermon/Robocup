var searchData=
[
  ['kd_5fpair_0',['Kd_pair',['../robot__movement_8h.html#aa8ecdbd9dd5646d7e3b1cf7ce49f2e1c',1,'robot_movement.h']]],
  ['ki_5fpair_1',['Ki_pair',['../robot__movement_8h.html#a57513d22142a56176a0e0dc93d6acc64',1,'robot_movement.h']]],
  ['kp_5fpair_2',['Kp_pair',['../robot__movement_8h.html#a26feac51f56cb054f03d5693f714a0d6',1,'robot_movement.h']]]
];
