var searchData=
[
  ['tca_5fselect_5fchannel_0',['tca_select_channel',['../encoder_8h.html#aa94ce35ff8dd906b6058cff31af5da85',1,'tca_select_channel(uint8_t channel):&#160;encoder.c'],['../encoder_8c.html#aa94ce35ff8dd906b6058cff31af5da85',1,'tca_select_channel(uint8_t channel):&#160;encoder.c']]]
];
