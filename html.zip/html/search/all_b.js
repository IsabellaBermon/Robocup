var searchData=
[
  ['n_5fsamples_0',['N_SAMPLES',['../robot__movement_8c.html#a864e696e58717460cdb19e5ce8f7ce20',1,'robot_movement.c']]],
  ['nordic_5fspp_5fpacket_5fhandler_1',['nordic_spp_packet_handler',['../bt__functions_8h.html#a05c3a41e74389157bc6d234a2042b595',1,'nordic_spp_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size):&#160;bt_functions.c'],['../bt__functions_8c.html#a05c3a41e74389157bc6d234a2042b595',1,'nordic_spp_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size):&#160;bt_functions.c']]],
  ['nvm_5fnum_5fdevice_5fdb_5fentries_2',['NVM_NUM_DEVICE_DB_ENTRIES',['../btstack__config_8h.html#a5bb3c5e561f61009d3096ef4d9d0f335',1,'btstack_config.h']]],
  ['nvm_5fnum_5flink_5fkeys_3',['NVM_NUM_LINK_KEYS',['../btstack__config_8h.html#aac3dab6800463253ec1ccb7ea2452df6',1,'btstack_config.h']]]
];
