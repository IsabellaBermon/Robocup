var searchData=
[
  ['have_5fassert_0',['HAVE_ASSERT',['../btstack__config_8h.html#ade12915fe0f02efc59e2fd1499faece7',1,'btstack_config.h']]],
  ['have_5fembedded_5ftime_5fms_1',['HAVE_EMBEDDED_TIME_MS',['../btstack__config_8h.html#a8254d3b46fbeef0a5e1e3b5f804b24de',1,'btstack_config.h']]],
  ['hci_5facl_5fchunk_5fsize_5falignment_2',['HCI_ACL_CHUNK_SIZE_ALIGNMENT',['../btstack__config_8h.html#aeadf3046aa823b66fbf9295572a40f59',1,'btstack_config.h']]],
  ['hci_5facl_5fpayload_5fsize_3',['HCI_ACL_PAYLOAD_SIZE',['../btstack__config_8h.html#a00bd3291e9c5dec8839883208cf201d3',1,'btstack_config.h']]],
  ['hci_5fhost_5facl_5fpacket_5flen_4',['HCI_HOST_ACL_PACKET_LEN',['../btstack__config_8h.html#a266c609d8305ae0e55689099e658038e',1,'btstack_config.h']]],
  ['hci_5fhost_5facl_5fpacket_5fnum_5',['HCI_HOST_ACL_PACKET_NUM',['../btstack__config_8h.html#af9a4fadd865bc6268c7062de7b4d7069',1,'btstack_config.h']]],
  ['hci_5fhost_5fsco_5fpacket_5flen_6',['HCI_HOST_SCO_PACKET_LEN',['../btstack__config_8h.html#a22b67b973d8e482bb7bdaedfe6abf78b',1,'btstack_config.h']]],
  ['hci_5fhost_5fsco_5fpacket_5fnum_7',['HCI_HOST_SCO_PACKET_NUM',['../btstack__config_8h.html#a8b8d87a0f8b47b22e1c904cd1d0ac71c',1,'btstack_config.h']]],
  ['hci_5foutgoing_5fpre_5fbuffer_5fsize_8',['HCI_OUTGOING_PRE_BUFFER_SIZE',['../btstack__config_8h.html#adee404d9507bb6cd795f3b9276dcc5e8',1,'btstack_config.h']]],
  ['hci_5freset_5fresend_5ftimeout_5fms_9',['HCI_RESET_RESEND_TIMEOUT_MS',['../btstack__config_8h.html#aeb57dc4aab549c40ca8f72d5af94a824',1,'btstack_config.h']]]
];
