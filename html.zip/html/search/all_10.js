var searchData=
[
  ['tca_5faddr_0',['TCA_ADDR',['../encoder_8h.html#af894088c7dad21639840f78ac3860aa8',1,'encoder.h']]],
  ['tca_5fselect_5fchannel_1',['tca_select_channel',['../encoder_8h.html#aa94ce35ff8dd906b6058cff31af5da85',1,'tca_select_channel(uint8_t channel):&#160;encoder.c'],['../encoder_8c.html#aa94ce35ff8dd906b6058cff31af5da85',1,'tca_select_channel(uint8_t channel):&#160;encoder.c']]],
  ['temp_2',['temp',['../robot__movement_8h.html#a54baf6d3cf7819fd576efcdeb5ed6d98',1,'robot_movement.h']]],
  ['turnmotor1_3',['turnmotor1',['../robot__movement_8h.html#a512c0a53f6d5b78eed7ce6c95911dd2c',1,'turnMotor1:&#160;robot_movement.c'],['../robot__movement_8c.html#a512c0a53f6d5b78eed7ce6c95911dd2c',1,'turnMotor1:&#160;robot_movement.c']]],
  ['turnmotor2_4',['turnmotor2',['../robot__movement_8h.html#a71599325f7a65b5234e77989d02774c5',1,'turnMotor2:&#160;robot_movement.c'],['../robot__movement_8c.html#a71599325f7a65b5234e77989d02774c5',1,'turnMotor2:&#160;robot_movement.c']]],
  ['turnmotor3_5',['turnmotor3',['../robot__movement_8h.html#aff99e3d3c5df735788ded35c395e96de',1,'turnMotor3:&#160;robot_movement.c'],['../robot__movement_8c.html#aff99e3d3c5df735788ded35c395e96de',1,'turnMotor3:&#160;robot_movement.c']]],
  ['turnmotor4_6',['turnmotor4',['../robot__movement_8h.html#a2a9b08a9040e9db99b44b9a3b810fed7',1,'turnMotor4:&#160;robot_movement.c'],['../robot__movement_8c.html#a2a9b08a9040e9db99b44b9a3b810fed7',1,'turnMotor4:&#160;robot_movement.c']]]
];
