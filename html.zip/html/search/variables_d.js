var searchData=
[
  ['send_5frequest_0',['send_request',['../bt__functions_8h.html#ae30e7b666e1fc6731dfb0b11cb989ec5',1,'send_request:&#160;bt_functions.c'],['../bt__functions_8c.html#ae30e7b666e1fc6731dfb0b11cb989ec5',1,'send_request:&#160;bt_functions.c']]],
  ['slice_5fnum_5f5_1',['slice_num_5',['../motor__config_8h.html#af787ea48ce80cf990ab997abdf3abdb3',1,'slice_num_5:&#160;motor_config.c'],['../motor__config_8c.html#af787ea48ce80cf990ab997abdf3abdb3',1,'slice_num_5:&#160;motor_config.c']]],
  ['slice_5fnum_5f6_2',['slice_num_6',['../motor__config_8h.html#ac6a8c444fdb01c3c2e44395fc5d6c86a',1,'slice_num_6:&#160;motor_config.c'],['../motor__config_8c.html#ac6a8c444fdb01c3c2e44395fc5d6c86a',1,'slice_num_6:&#160;motor_config.c']]],
  ['sum_3',['sum',['../_m_p_u6050__i2c_8h.html#a930b83edda39ee8cfa78dd4574a50bc3',1,'sum:&#160;MPU6050_i2c.c'],['../_m_p_u6050__i2c_8c.html#a930b83edda39ee8cfa78dd4574a50bc3',1,'sum:&#160;MPU6050_i2c.c']]]
];
