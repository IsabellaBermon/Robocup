var searchData=
[
  ['filter_5fmedian_5fmoving_0',['filter_median_moving',['../_m_p_u6050__i2c_8h.html#a9e401b058b89a20227a42e7eac6d1134',1,'filter_median_moving(int new_reading):&#160;MPU6050_i2c.c'],['../_m_p_u6050__i2c_8c.html#a9e401b058b89a20227a42e7eac6d1134',1,'filter_median_moving(int new_reading):&#160;MPU6050_i2c.c']]],
  ['filtrod_1',['filtroD',['../control__functions_8c.html#afcd7e112f9202fae3d287814f54a56c9',1,'control_functions.c']]],
  ['funcionalidades_20principales_2',['Funcionalidades Principales',['../index.html#func_sec',1,'']]]
];
