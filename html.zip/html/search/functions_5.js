var searchData=
[
  ['hci_5fpacket_5fhandler_0',['hci_packet_handler',['../bt__functions_8h.html#a1db4121f3b3d746dd6d9278552f5c1a3',1,'hci_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size):&#160;bt_functions.c'],['../bt__functions_8c.html#a1db4121f3b3d746dd6d9278552f5c1a3',1,'hci_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size):&#160;bt_functions.c']]]
];
