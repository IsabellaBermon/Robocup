var searchData=
[
  ['calibrate_0',['calibrate',['../robot__movement_8h.html#ad4a7316a51b17d0f691bb3e33b95a5ad',1,'calibrate():&#160;robot_movement.c'],['../robot__movement_8c.html#ad4a7316a51b17d0f691bb3e33b95a5ad',1,'calibrate():&#160;robot_movement.c']]],
  ['circularmovement_1',['circularmovement',['../robot__movement_8h.html#af0e24be833d0b4c1cc74dfc68b42cf3e',1,'circularMovement(double r, int angle):&#160;robot_movement.c'],['../robot__movement_8c.html#af0e24be833d0b4c1cc74dfc68b42cf3e',1,'circularMovement(double r, int angle):&#160;robot_movement.c']]],
  ['circunference_2',['circunference',['../control__functions_8h.html#a647ff1a6b2434a763bf1eff01b3164f7',1,'control_functions.h']]],
  ['componentes_20del_20sistema_3',['Componentes del Sistema',['../index.html#comp_sec',1,'']]],
  ['con_5fhandle_4',['con_handle',['../bt__functions_8h.html#a02bea55afda5d53df054b197b9f51f02',1,'con_handle:&#160;bt_functions.c'],['../bt__functions_8c.html#a02bea55afda5d53df054b197b9f51f02',1,'con_handle:&#160;bt_functions.c']]],
  ['control_5ffunctions_2ec_5',['control_functions.c',['../control__functions_8c.html',1,'']]],
  ['control_5ffunctions_2eh_6',['control_functions.h',['../control__functions_8h.html',1,'']]]
];
