var searchData=
[
  ['updateangle_0',['updateangle',['../robot__movement_8h.html#ae867818f4e1ea5245f9a111f2f98d2d1',1,'updateAngle():&#160;robot_movement.c'],['../robot__movement_8c.html#ae867818f4e1ea5245f9a111f2f98d2d1',1,'updateAngle():&#160;robot_movement.c']]]
];
