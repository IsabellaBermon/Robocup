var searchData=
[
  ['getangle_0',['getangle',['../encoder_8h.html#a99fde70b26431b61a6df10a93ddf739c',1,'getAngle():&#160;encoder.c'],['../encoder_8c.html#a99fde70b26431b61a6df10a93ddf739c',1,'getAngle():&#160;encoder.c']]],
  ['getanglesmotors_1',['getAnglesMotors',['../main_8c.html#ac7fbba77b2b0fb133c0825b3e15d1aa8',1,'main.c']]],
  ['getoffsets_2',['getoffsets',['../encoder_8h.html#a80da025c4d1aa62790c4af7ffcf5a948',1,'getOffsets():&#160;encoder.c'],['../encoder_8c.html#a80da025c4d1aa62790c4af7ffcf5a948',1,'getOffsets():&#160;encoder.c']]]
];
