var searchData=
[
  ['index_5fmedia_0',['index_media',['../_m_p_u6050__i2c_8h.html#a748c852908a9ed7158e9866d0f2a4cec',1,'index_media:&#160;MPU6050_i2c.c'],['../_m_p_u6050__i2c_8c.html#a748c852908a9ed7158e9866d0f2a4cec',1,'index_media:&#160;MPU6050_i2c.c']]],
  ['initbluetooth_1',['initbluetooth',['../bt__functions_8h.html#abbfc87609013d91f12b9af928d51856d',1,'initBluetooth():&#160;bt_functions.c'],['../bt__functions_8c.html#abbfc87609013d91f12b9af928d51856d',1,'initBluetooth():&#160;bt_functions.c']]],
  ['initi2c_2',['initi2c',['../encoder_8h.html#abe298a3c1d98035cebe8b0535db549fa',1,'initI2C():&#160;encoder.c'],['../encoder_8c.html#abe298a3c1d98035cebe8b0535db549fa',1,'initI2C():&#160;encoder.c']]],
  ['initmotor_3',['initmotor',['../motor__config_8h.html#a72af49fb7191c300fa1a1a8ec5c91b13',1,'initMotor():&#160;motor_config.c'],['../motor__config_8c.html#a72af49fb7191c300fa1a1a8ec5c91b13',1,'initMotor():&#160;motor_config.c']]],
  ['integralerror1_5f4_4',['integralerror1_4',['../control__functions_8h.html#af8f515d249f3032512791f96792aa0c2',1,'integralError1_4:&#160;control_functions.c'],['../control__functions_8c.html#af8f515d249f3032512791f96792aa0c2',1,'integralError1_4:&#160;control_functions.c']]],
  ['integralerror2_5f3_5',['integralerror2_3',['../control__functions_8h.html#a79460cedcaf7a965c6e4be42beaa72b5',1,'integralError2_3:&#160;control_functions.c'],['../control__functions_8c.html#a79460cedcaf7a965c6e4be42beaa72b5',1,'integralError2_3:&#160;control_functions.c']]],
  ['integralerror_5fpair_6',['integralError_pair',['../robot__movement_8h.html#a8b46103a4af0a8122fdfa4a42f56f8f6',1,'robot_movement.h']]],
  ['integralerrorangle_7',['integralErrorAngle',['../control__functions_8c.html#a719058d43cd2bfcb2839058abbec7c7e',1,'control_functions.c']]],
  ['introducción_8',['Introducción',['../index.html#intro_sec',1,'']]]
];
