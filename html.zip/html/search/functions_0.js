var searchData=
[
  ['adjustmotorspeed_0',['adjustmotorspeed',['../control__functions_8h.html#a2304053fc1f7b418d3b1cce677b64cf1',1,'adjustMotorSpeed(uint motorNumber, double adjustment):&#160;control_functions.c'],['../control__functions_8c.html#a2304053fc1f7b418d3b1cce677b64cf1',1,'adjustMotorSpeed(uint motorNumber, double adjustment):&#160;control_functions.c']]],
  ['anglesubtraction_1',['anglesubtraction',['../encoder_8h.html#aec3638c2c64f9d0c81210f33ec21eb75',1,'angleSubtraction(int16_t angle, int16_t angleOffset):&#160;encoder.c'],['../encoder_8c.html#aec3638c2c64f9d0c81210f33ec21eb75',1,'angleSubtraction(int16_t angle, int16_t angleOffset):&#160;encoder.c']]]
];
