var searchData=
[
  ['readandprocessaccelerometer_0',['readAndProcessAccelerometer',['../robot__movement_8c.html#a5d8034c437acbb701df0c918360a1536',1,'robot_movement.c']]],
  ['readangleraw_1',['readangleraw',['../encoder_8h.html#a499b9fd9c40686dffebf63555b580e50',1,'readAngleRaw(int16_t *buffer):&#160;encoder.c'],['../encoder_8c.html#a499b9fd9c40686dffebf63555b580e50',1,'readAngleRaw(int16_t *buffer):&#160;encoder.c']]],
  ['restartcontrol_2',['restartcontrol',['../control__functions_8h.html#adf81d56c66532a03608d9a67c679646a',1,'restartControl():&#160;control_functions.c'],['../control__functions_8c.html#adf81d56c66532a03608d9a67c679646a',1,'restartControl():&#160;control_functions.c']]],
  ['restartmovement_3',['restartmovement',['../robot__movement_8h.html#aefd59c6f95224aeb7db87f3e6d155b29',1,'restartMovement():&#160;robot_movement.c'],['../robot__movement_8c.html#aefd59c6f95224aeb7db87f3e6d155b29',1,'restartMovement():&#160;robot_movement.c']]],
  ['rotation_4',['rotation',['../robot__movement_8h.html#abab8dcde6b2ce253797ccd3d666c98ef',1,'rotation(double rotationAngle):&#160;robot_movement.c'],['../robot__movement_8c.html#abab8dcde6b2ce253797ccd3d666c98ef',1,'rotation(double rotationAngle):&#160;robot_movement.c']]]
];
