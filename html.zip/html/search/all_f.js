var searchData=
[
  ['scl_0',['SCL',['../encoder_8h.html#ab5ffc4751921608954bb7a5687566b2d',1,'encoder.h']]],
  ['scl_5fmpu_1',['SCL_MPU',['../_m_p_u6050__i2c_8h.html#a7590ec5996ae3115bc9803907f12360f',1,'MPU6050_i2c.h']]],
  ['sda_5fmpu_2',['SDA_MPU',['../_m_p_u6050__i2c_8h.html#ad3577e024b0aa2848689ed9f7e29d8dc',1,'MPU6050_i2c.h']]],
  ['send_5frequest_3',['send_request',['../bt__functions_8h.html#ae30e7b666e1fc6731dfb0b11cb989ec5',1,'send_request:&#160;bt_functions.c'],['../bt__functions_8c.html#ae30e7b666e1fc6731dfb0b11cb989ec5',1,'send_request:&#160;bt_functions.c']]],
  ['sig_5fsda_4',['SIG_SDA',['../encoder_8h.html#a47b2ced86361f2c86c87cf949eddcf5f',1,'encoder.h']]],
  ['sistema_5',['Componentes del Sistema',['../index.html#comp_sec',1,'']]],
  ['slice_5fnum_5f5_6',['slice_num_5',['../motor__config_8h.html#af787ea48ce80cf990ab997abdf3abdb3',1,'slice_num_5:&#160;motor_config.c'],['../motor__config_8c.html#af787ea48ce80cf990ab997abdf3abdb3',1,'slice_num_5:&#160;motor_config.c']]],
  ['slice_5fnum_5f6_7',['slice_num_6',['../motor__config_8h.html#ac6a8c444fdb01c3c2e44395fc5d6c86a',1,'slice_num_6:&#160;motor_config.c'],['../motor__config_8c.html#ac6a8c444fdb01c3c2e44395fc5d6c86a',1,'slice_num_6:&#160;motor_config.c']]],
  ['sum_8',['sum',['../_m_p_u6050__i2c_8h.html#a930b83edda39ee8cfa78dd4574a50bc3',1,'sum:&#160;MPU6050_i2c.c'],['../_m_p_u6050__i2c_8c.html#a930b83edda39ee8cfa78dd4574a50bc3',1,'sum:&#160;MPU6050_i2c.c']]]
];
