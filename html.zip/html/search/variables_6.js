var searchData=
[
  ['hci_5fevent_5fcallback_5fregistration_0',['hci_event_callback_registration',['../bt__functions_8h.html#a8bf2c8f8ea4d8cfcfd790084b8db517a',1,'hci_event_callback_registration:&#160;bt_functions.c'],['../bt__functions_8c.html#a8bf2c8f8ea4d8cfcfd790084b8db517a',1,'hci_event_callback_registration:&#160;bt_functions.c']]]
];
