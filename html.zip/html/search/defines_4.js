var searchData=
[
  ['max_5fatt_5fdb_5fsize_0',['MAX_ATT_DB_SIZE',['../btstack__config_8h.html#a520e780677c9326260202357e0df37a5',1,'btstack_config.h']]],
  ['max_5fnr_5fcontroller_5facl_5fbuffers_1',['MAX_NR_CONTROLLER_ACL_BUFFERS',['../btstack__config_8h.html#a88272ff7a2b0bf4aa61150b43bdcb047',1,'btstack_config.h']]],
  ['max_5fnr_5fcontroller_5fsco_5fpackets_2',['MAX_NR_CONTROLLER_SCO_PACKETS',['../btstack__config_8h.html#a3f33a965d534219f267b1e62ac75c6b3',1,'btstack_config.h']]],
  ['max_5fnr_5fgatt_5fclients_3',['MAX_NR_GATT_CLIENTS',['../btstack__config_8h.html#aa8286f3695272d19f3d273113b6d17b1',1,'btstack_config.h']]],
  ['max_5fnr_5fhci_5fconnections_4',['MAX_NR_HCI_CONNECTIONS',['../btstack__config_8h.html#aca157ea5ae3e04c3c0eb0f8a21d15cff',1,'btstack_config.h']]],
  ['max_5fnr_5fle_5fdevice_5fdb_5fentries_5',['MAX_NR_LE_DEVICE_DB_ENTRIES',['../btstack__config_8h.html#acd107b641df68039d1449aa7b3e97d1c',1,'btstack_config.h']]],
  ['max_5fnr_5fsm_5flookup_5fentries_6',['MAX_NR_SM_LOOKUP_ENTRIES',['../btstack__config_8h.html#a48aa6c5c75a6634dd27c152d14f40d69',1,'btstack_config.h']]],
  ['max_5fnr_5fwhitelist_5fentries_7',['MAX_NR_WHITELIST_ENTRIES',['../btstack__config_8h.html#aef14f46f4eb378ed5819c8d564d48d22',1,'btstack_config.h']]],
  ['mpu6050_5faddr_8',['MPU6050_addr',['../_m_p_u6050__i2c_8h.html#a4d014791674c91d53cb42097785a5e25',1,'MPU6050_i2c.h']]],
  ['mpu6050_5fi2c_9',['MPU6050_i2c',['../_m_p_u6050__i2c_8h.html#a1716883633d86e3659535f181833539e',1,'MPU6050_i2c.h']]]
];
