var searchData=
[
  ['calibrate_0',['calibrate',['../robot__movement_8h.html#ad4a7316a51b17d0f691bb3e33b95a5ad',1,'calibrate():&#160;robot_movement.c'],['../robot__movement_8c.html#ad4a7316a51b17d0f691bb3e33b95a5ad',1,'calibrate():&#160;robot_movement.c']]],
  ['circularmovement_1',['circularmovement',['../robot__movement_8h.html#af0e24be833d0b4c1cc74dfc68b42cf3e',1,'circularMovement(double r, int angle):&#160;robot_movement.c'],['../robot__movement_8c.html#af0e24be833d0b4c1cc74dfc68b42cf3e',1,'circularMovement(double r, int angle):&#160;robot_movement.c']]]
];
