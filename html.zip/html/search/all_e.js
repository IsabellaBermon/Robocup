var searchData=
[
  ['radio_0',['radio',['../control__functions_8h.html#a0643e1d289e7d7bb19b3fd36f7044404',1,'control_functions.h']]],
  ['radiobt_1',['radiobt',['../bt__functions_8h.html#aebbbf59c3ddab9dbb921620a0eb07cec',1,'radioBt:&#160;bt_functions.c'],['../bt__functions_8c.html#aebbbf59c3ddab9dbb921620a0eb07cec',1,'radioBt:&#160;bt_functions.c']]],
  ['readandprocessaccelerometer_2',['readAndProcessAccelerometer',['../robot__movement_8c.html#a5d8034c437acbb701df0c918360a1536',1,'robot_movement.c']]],
  ['readangleraw_3',['readangleraw',['../encoder_8h.html#a499b9fd9c40686dffebf63555b580e50',1,'readAngleRaw(int16_t *buffer):&#160;encoder.c'],['../encoder_8c.html#a499b9fd9c40686dffebf63555b580e50',1,'readAngleRaw(int16_t *buffer):&#160;encoder.c']]],
  ['refvelmotor1_4',['refVelMotor1',['../robot__movement_8c.html#af57bbb7499f28a7036eef98488804f8e',1,'robot_movement.c']]],
  ['refvelmotor2_5',['refVelMotor2',['../robot__movement_8c.html#a899a9dfd5ad3963460cc0f6f435be184',1,'robot_movement.c']]],
  ['refvelmotor3_6',['refVelMotor3',['../robot__movement_8c.html#a1e811e0a168b8226649d210e61143971',1,'robot_movement.c']]],
  ['refvelmotor4_7',['refVelMotor4',['../robot__movement_8c.html#a3c87a0dac841101d2a185bdc906e53c4',1,'robot_movement.c']]],
  ['restartcontrol_8',['restartcontrol',['../control__functions_8h.html#adf81d56c66532a03608d9a67c679646a',1,'restartControl():&#160;control_functions.c'],['../control__functions_8c.html#adf81d56c66532a03608d9a67c679646a',1,'restartControl():&#160;control_functions.c']]],
  ['restartmovement_9',['restartmovement',['../robot__movement_8h.html#aefd59c6f95224aeb7db87f3e6d155b29',1,'restartMovement():&#160;robot_movement.c'],['../robot__movement_8c.html#aefd59c6f95224aeb7db87f3e6d155b29',1,'restartMovement():&#160;robot_movement.c']]],
  ['robocup_10',['Documentación Robocup',['../index.html',1,'']]],
  ['robot_5fmovement_2ec_11',['robot_movement.c',['../robot__movement_8c.html',1,'']]],
  ['robot_5fmovement_2eh_12',['robot_movement.h',['../robot__movement_8h.html',1,'']]],
  ['robotangle_13',['robotangle',['../robot__movement_8h.html#ae11defa3227c87581a5fbe499df218f7',1,'robotAngle:&#160;robot_movement.c'],['../robot__movement_8c.html#ae11defa3227c87581a5fbe499df218f7',1,'robotAngle:&#160;robot_movement.c']]],
  ['rotation_14',['rotation',['../robot__movement_8h.html#abab8dcde6b2ce253797ccd3d666c98ef',1,'rotation(double rotationAngle):&#160;robot_movement.c'],['../robot__movement_8c.html#abab8dcde6b2ce253797ccd3d666c98ef',1,'rotation(double rotationAngle):&#160;robot_movement.c']]]
];
