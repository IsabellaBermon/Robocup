var searchData=
[
  ['nordic_5fspp_5fpacket_5fhandler_0',['nordic_spp_packet_handler',['../bt__functions_8h.html#a05c3a41e74389157bc6d234a2042b595',1,'nordic_spp_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size):&#160;bt_functions.c'],['../bt__functions_8c.html#a05c3a41e74389157bc6d234a2042b595',1,'nordic_spp_packet_handler(uint8_t packet_type, uint16_t channel, uint8_t *packet, uint16_t size):&#160;bt_functions.c']]]
];
